import xbmcaddon
import os

#########################################################
#          Global Variables - DON'T EDIT!!!             #
#########################################################
ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
PATH = xbmcaddon.Addon().getAddonInfo('path')
ART = os.path.join(PATH, 'resources', 'media')
#########################################################

#########################################################
#         User Edit Variables                           #
#########################################################
ADDONTITLE = '[COLOR gold][B]MEYIST[/B][/COLOR] Vision'
BUILDERNAME = 'Meyist'
EXCLUDES = [ADDON_ID, 'repository.meyist']

# Ton lien Dropbox vers build.txt (configuré en téléchargement direct)
BUILDFILE = 'https://www.dropbox.com/scl/fi/g723gexzwo3qngs2f97dd/build.txt?rlkey=io7i8c78ibwr7a7ss5jj2uyle&st=1c7564fd&dl=1'

# Vérification des mises à jour (0 = à chaque démarrage)
UPDATECHECK = 0

APKFILE = 'http://'
YOUTUBETITLE = ''
YOUTUBEFILE = 'http://'
ADDONFILE = 'http://'
ADVANCEDFILE = 'http://'
#########################################################

#########################################################
#         Theming Menu Items                            #
#########################################################
ICONBUILDS = os.path.join(ART, 'builds.png')
ICONMAINT = os.path.join(ART, 'maintenance.png')
ICONSPEED = os.path.join(ART, 'speed.png')
ICONAPK = os.path.join(ART, 'apkinstaller.png')
ICONADDONS = os.path.join(ART, 'addoninstaller.png')
ICONYOUTUBE = os.path.join(ART, 'youtube.png')
ICONSAVE = os.path.join(ART, 'savedata.png')
ICONTRAKT = os.path.join(ART, 'keeptrakt.png')
ICONREAL = os.path.join(ART, 'keepdebrid.png')
ICONLOGIN = os.path.join(ART, 'keeplogin.png')
ICONCONTACT = os.path.join(ART, 'information.png')
ICONSETTINGS = os.path.join(ART, 'settings.png')

HIDESPACERS = 'No'
SPACER = '='

COLOR1 = 'gold'
COLOR2 = 'white'

THEME1 = u'[COLOR {color1}][I]([COLOR {color1}][B]MEYIST[/B][/COLOR][COLOR {color2}]Vision[COLOR {color1}])[/I][/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)
THEME2 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR1)
THEME3 = u'[COLOR {color1}]{{}}[/COLOR]'.format(color1=COLOR1)
THEME4 = u'[COLOR {color1}]Build Actuel:[/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)
THEME5 = u'[COLOR {color1}]Theme Actuel:[/COLOR] [COLOR {color2}]{{}}[/COLOR]'.format(color1=COLOR1, color2=COLOR2)

HIDECONTACT = 'No'
CONTACT = 'Merci d avoir choisi Meyist Vision.\n\nRetrouvez mes mises a jour sur mon depot Github.'
CONTACTICON = os.path.join(ART, 'qricon.png')
CONTACTFANART = 'http://'
#########################################################

#########################################################
#         Auto Update / Auto Install (Désactivés)       #
#########################################################
AUTOUPDATE = 'No'
AUTOINSTALL = 'No'
REPOID = 'repository.meyist'
REPOADDONXML = 'http://'
REPOZIPURL = 'http://'
#########################################################

#########################################################
#         Notification Window                           #
#########################################################
ENABLE = 'Yes'
NOTIFICATION = 'http://'
HEADERTYPE = 'Text'
FONTHEADER = 'Font14'
HEADERMESSAGE = '[COLOR gold][B]MEYIST[/B][/COLOR] Vision'
HEADERIMAGE = 'http://'
FONTSETTINGS = 'Font13'
BACKGROUND = 'http://'
#########################################################